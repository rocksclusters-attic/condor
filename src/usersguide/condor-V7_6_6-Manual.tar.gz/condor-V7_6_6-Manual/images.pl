# LaTeX2HTML 2002-2-1 (1.70)
# Associate images original text with physical files.


$key = q/deltat;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="17" HEIGHT="14" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img20.png"
 ALT="$\delta t$">|; 

$key = q/pi_e(u,t);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="53" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img24.png"
 ALT="$\pi_e(u,t)$">|; 

$key = q/fbox{Thissectionhasnotyetbeencompleted};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="295" HEIGHT="40" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img17.png"
 ALT="\fbox{This section has not yet been completed}">|; 

$key = q/includegraphics{admin-manslashmachine-states.eps};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="526" HEIGHT="347" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img27.png"
 ALT="\includegraphics{admin-man/machine-states.eps}">|; 

$key = q/includegraphics{admin-manslashview-screenshot.ps};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="636" HEIGHT="587" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img9.png"
 ALT="\includegraphics{admin-man/view-screenshot.ps}">|; 

$key = q/t=9+2^5=9+32=41seconds;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="234" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img14.png"
 ALT="$t = 9 + 2^5 = 9 + 32 = 41 seconds$">|; 

$key = q/includegraphics{user-manslashsplice-s1.eps};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="278" HEIGHT="692" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img6.png"
 ALT="\includegraphics{user-man/splice-s1.eps}">|; 

$key = q/t=9+2^1=9+2=11seconds;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="226" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img12.png"
 ALT="$t = 9 + 2^1 = 9 + 2 = 11 seconds$">|; 

$key = q/includegraphics{admin-manslashpool-arch.eps};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="464" HEIGHT="357" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img8.png"
 ALT="\includegraphics{admin-man/pool-arch.eps}">|; 

$key = q/mathtt{backslash};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="11" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img10.png"
 ALT="$\mathtt{\backslash}$">|; 

$key = q/t=9+2^0=9+1=10seconds;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="226" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img11.png"
 ALT="$t = 9 + 2^0 = 9 + 1 = 10 seconds$">|; 

$key = q/t=9+2^2=9+4=13seconds;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="226" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img13.png"
 ALT="$t = 9 + 2^2 = 9 + 4 = 13 seconds$">|; 

$key = q/includegraphics{user-manslashsplice-X.eps};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="255" HEIGHT="232" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img5.png"
 ALT="\includegraphics{user-man/splice-X.eps}">|; 

$key = q/{displaymath}pi_e(u,t)=pi_r(u,t)timesf(u,t){displaymath};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="184" HEIGHT="28" BORDER="0"
 SRC="|."$dir".q|img25.png"
 ALT="\begin{displaymath}\pi_e(u,t) = \pi_r(u,t)\times f(u,t)\end{displaymath}">|; 

$key = q/pi_r(u,t);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="53" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img19.png"
 ALT="$\pi_r(u,t)$">|; 

$key = q/t=9+2^8=9+256=265seconds;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="250" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img15.png"
 ALT="$t = 9 + 2^8 = 9 + 256 = 265 seconds$">|; 

$key = q/fbox{Thissectionhasnotyetbeenwritten};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="274" HEIGHT="40" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img18.png"
 ALT="\fbox{This section has not yet been written}">|; 

$key = q/{figure}preform{<verbatim_mark>verbatim2242#preform{{{{figure};FSF=1.6;AAF/;
$cached_env_img{$key} = q|<IMG
 WIDTH="316" HEIGHT="131" BORDER="0"
 SRC="|."$dir".q|img30.png"
 ALT="\begin{figure}\begin{verbatim}- (unary negation) (high precedence)
* /
+ -...
... &gt;= &gt;
== != =?= =!=
&amp;&amp;
\vert\vert (low precedence)\end{verbatim}
\end{figure}">|; 

$key = q/{displaymath}pi_r(u,t)=betatimespi(u,t-deltat)+(1-beta)timesrho(u,t){displaymath};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="308" HEIGHT="28" BORDER="0"
 SRC="|."$dir".q|img21.png"
 ALT="\begin{displaymath}\pi_r(u,t) = \beta\times\pi(u,t-\delta t) + (1-\beta)\times\rho(u,t)\end{displaymath}">|; 

$key = q/t=9+2^{12}=9+4096=4105seconds;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="273" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img16.png"
 ALT="$t = 9 + 2^{12} = 9 + 4096 = 4105 seconds$">|; 

$key = q/beta=0.5^{{deltat}slashh};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="80" HEIGHT="36" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img23.png"
 ALT="$\beta=0.5^{{\delta t}/h}$">|; 

$key = q/{figure}{footnotesize{preform{<verbatim_mark>verbatim2239#preform{{normalsize{{{{figure};FSF=1.6;AAF/;
$cached_env_img{$key} = q|<IMG
 WIDTH="499" HEIGHT="148" BORDER="0"
 SRC="|."$dir".q|img29.png"
 ALT="\begin{figure}\footnotesize
\begin{verbatim}MyType = ''Machine''
TargetType = ...
...\vert LoadAvg&lt;=0.3 &amp;&amp; KeyboardIdle&gt;15*60\end{verbatim}
\normalsize\end{figure}">|; 

$key = q/includegraphics{gridsslashgfig1.eps};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="580" HEIGHT="451" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img31.png"
 ALT="\includegraphics{grids/gfig1.eps}">|; 

$key = q/includegraphics{user-manslashsplice-simple.eps};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="229" HEIGHT="314" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img4.png"
 ALT="\includegraphics{user-man/splice-simple.eps}">|; 

$key = q/includegraphics{user-manslashdagman-node.eps};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="346" HEIGHT="346" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img2.png"
 ALT="\includegraphics{user-man/dagman-node.eps}">|; 

$key = q/includegraphics{user-manslashsplice-complex.eps};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="574" HEIGHT="610" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img7.png"
 ALT="\includegraphics{user-man/splice-complex.eps}">|; 

$key = q/includegraphics{user-manslashdagman-diamond.eps};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="96" HEIGHT="96" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img3.png"
 ALT="\includegraphics{user-man/dagman-diamond.eps}">|; 

$key = q/beta;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="13" HEIGHT="29" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img26.png"
 ALT="$\beta$">|; 

$key = q/pm2^{31};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="37" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img32.png"
 ALT="$\pm2^{31}$">|; 

$key = q/nomath_inline}textregisterednomath_inline};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="18" HEIGHT="28" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img1.png"
 ALT="\textregistered">|; 

$key = q/rho(u,t);MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="46" HEIGHT="31" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img22.png"
 ALT="$\rho(u,t)$">|; 

$key = q/includegraphics{admin-manslashmachine-activities.eps};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="660" HEIGHT="636" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img28.png"
 ALT="\includegraphics{admin-man/machine-activities.eps}">|; 

1;


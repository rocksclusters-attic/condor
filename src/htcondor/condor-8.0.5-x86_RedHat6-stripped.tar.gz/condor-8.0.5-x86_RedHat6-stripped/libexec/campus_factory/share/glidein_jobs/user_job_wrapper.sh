#!/bin/sh

exec $@



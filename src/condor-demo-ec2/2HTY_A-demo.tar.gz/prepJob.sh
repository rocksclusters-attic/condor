#/bin/bash

function CheckArgs () {
    Receptor=${1%/}  # remove trailing /
    DpfDir=${2%/}    # remove trailing /
    echo "Receptor" $Receptor "dpf" $DpfDir 

    if [ ! -d $Receptor ] ; then
        echo "Directory $Receptor does not exist"
        exit 1
    fi

    if [ ! -d $DpfDir ] ; then
        echo "Directory $DpfDir does not exist"
        exit 1
    fi
}

function CreateLinks () {
    ext=dpf
    files=`ls $DpfDir/ | grep $ext`

    where=$PWD
    cd $DpfDir
    j=0
    for i in $files ; 
    do
        if [ -h $i ] ; then
            continue
        fi
        if [ ! -e $j.$ext ] ; then
                ln -s $i $j.$ext
        fi
        let j++
    done
    let njobs=j
    cd $where
}

function CreateSubFile () {
    sub=$Receptor.sub
    if [ ! -d logs-$Receptor ] ; then
        mkdir logs-$Receptor
    fi

    cat /dev/null > $sub

echo "
##########################################
##   $Receptor job submit file ##
##########################################

getenv = true
Executable = run_adt.sh
Arguments  = \$(process).dpf
Log        = logs-$Receptor/$Receptor.log.\$(process)
Output     = logs-$Receptor/$Receptor.out.\$(process)
Error      = logs-$Receptor/$Receptor.err.\$(process)

should_tranfer_files = IF_NEEDED
tranfer_executable = True
when_to_transfer_output = ON_EXIT

transfer_input_files = $DpfDir/\$(process).dpf, \\ " >> $sub

    files=`ls $Receptor/ | grep map`
    for i in $files ; 
    do
        echo "$Receptor/$i, \\" >> $sub
    done

echo " " >> $sub
echo "notification = Error" >> $sub
echo "queue $njobs"         >> $sub

}

if [ $# -ne 2 ]; then
    echo "Usage: $0 receptorDir dpfDir"
    echo "    rDir   - receptor directory"
    echo "    dpfDir - directory with dpf files"
    exit 1
fi

CheckArgs $1 $2
CreateLinks
CreateSubFile

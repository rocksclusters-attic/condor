#!/bin/bash

# variables definition 
DBDIR=/share/apps/db/NCIdiversity
Executable="/opt/bio/autodocksuite/bin/autodock4"

# functions definition
usage () {
   echo "Usage: $0 paramFile"
   echo "       paramFile - dpf file" 
}

runAutodock () {
    # find needed ligand file
    pdbqt=`grep pdbqt $dpf | awk '{print $2}'`
    if [ -f $DBDIR/$pdbqt ] ; then
        ln -s $DBDIR/$pdbqt .
    else
        echo "File $DBDIR/$pdbqt does not exist"
        exit 1 
    fi

    # run autodock
    log=${pdbqt%.*}.result
    Arguments="-p $dpf -l $log"
    $Executable $Arguments
    rm $pdbqt
}

# execute section
if [ $# -ne 1 ]; then
    usage
    exit 1
fi

dpf=$1
runAutodock
